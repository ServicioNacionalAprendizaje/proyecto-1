<?php

//error_reporting(0);
//include "Netflix.class.php";
include "Netflix2.class.php";
include('../libreria/lib/nusoap.php');

//define("DEBUG", TRUE);
echo "entro";
error_reporting(0);
$_REQUEST['evento'] = 'COBRO';
// ini_set('display_errors', '1');

if ($_REQUEST) {

    if ($_REQUEST['evento'] == "AMCO") {
        $db_netflix = new Netflix();
        $db_netflix->posactiva_amco();
    } elseif ($_REQUEST['evento'] == "HUB_BID") {
        $b = 0;
        $db_netflix = new Netflix();
        while ($b <= 10000000) {
            $db_netflix->procesa_hub_bid();
            $b++;
            echo "<br>" . $b . "consecutivo<br>";
        }
    } elseif ($_REQUEST['evento'] == "COBRO") {
        $b = 0;
        $db_netflix = new Netflix();
        // while ($b <= 10000000) {
        $db_netflix->procesa_cobro();
        $b++;
        echo "<br>" . $b . "consecutivo<br>";
        //}
    } elseif ($_REQUEST['evento'] == "NETFLIX") {
        $b = 0;
        $db_netflix = new Netflix();
        while ($b <= 10000000) {
            $db_netflix->procesa_netflix();
            $b++;
            echo "<br>" . $b . "consecutivo<br>";
        }
    } elseif ($_REQUEST['evento'] == "NETFLIX_UPGRATE") {
        $b = 0;
        $db_netflix = new Netflix();
        while ($b <= 10000000) {
            $db_netflix->procesa_netflix();
            $b++;
            echo "<br>" . $b . "consecutivo<br>";
        }
    } elseif ($_REQUEST['evento'] == "GENEREATE") {

        $b = 0;
        $db_netflix = new Netflix();
        while ($b <= 10000000) {

            $db_netflix->procesa_generate();
            $b++;
            echo "<br>" . $b . "consecutivo<br>";
        }
    } elseif ($_REQUEST['evento'] == "CREA_CUSTOMER") {
        $db_netflix = new Netflix();
        $db_netflix->procesa_create();
    } else {
        $db_netflix = new Netflix();
    }
}
?>