<?php

class Dispensiario {

    const server = 'localhost';
    const username = 'root';
    const passs = '';
    const db = 'login_register_db';

    /**
     * 
     * @return \mysqli
     */
    static function connect() {


        $servername = self::server;
        $username = self::username;
        $password = self::passs;
        $dbname = self::db;

        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    /**
     * 
     * @param type $id_eps
     * @return string
     */
    static function dispensiario_eps($id_eps = '') {
        // Create connection

        $conn = Dispensiario::connect();
        $sql = "SELECT ds.id_dispensiario,ds.nombre,ds.direccion from dispensiario ds 
               inner join    eps_dispensiario  ed on ed.id_dispensiario = ds.id_dispensiario
		WHERE ed.id_eps='$id_eps' and ds.estado ='A'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array('id_dispensiario' => $row["id_dispensiario"], 'nombre' => $row["nombre"], 'nombre' => $row["nombre"], 'direccion' => $row["direccion"]);
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @return string
     */
    function dispensiario() {
        $conn = Registro::connect();
        $sql = "SELECT * from dispensiario estado ='A";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array('id_dispensiario' => $row["id_dispensiario"], 'nombre' => $row["nombre"], 'direccion' => $row["direccion"]);
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

}

?> 