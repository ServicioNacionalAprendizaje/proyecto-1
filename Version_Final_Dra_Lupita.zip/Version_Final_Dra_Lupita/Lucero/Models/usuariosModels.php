<?php

class Usuarios {

    const server = 'localhost';
    const username = 'root';
    const passs = '';
    const db = 'login_register_db';

    /**
     * 
     * @return \mysqli
     */
    function connect() {


        $servername = self::server;
        $username = self::username;
        $password = self::passs;
        $dbname = self::db;

        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    /**
     * 
     * @param type $usuario
     * @param type $clave
     * @return string
     */
    public function usuario_login($usuario = '', $clave = '') {
        // Create connection

        $conn = Usuarios ::connect();
        $sql = "SELECT id,documento,nombre,email,apellido,id_rol
            from usuarios us    
        inner join usuarios_roles ur on  ur.id_usuario = us.id 
        WHERE us.email= '$usuario' and  us.password = '$clave' limit 0,1 ";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {

                $reponse = array('id' => $row["id"], 'nombre' => $row["nombre"], 'email' => $row["email"], 'documento' => $row["documento"], 'id_rol' => $row["id_rol"]);
            }
        } else {
            $reponse = "error";
        }

        return $reponse;
        $conn->close();
    }

    /**
     * 
     * @param type $documento
     * @return string
     */
    public function usuario_search($documento = '') {
        // Create connection

        $conn = Usuarios ::connect();
        $sql = "SELECT id,documento,nombre, apellido
            from usuarios us    
        inner join usuarios_roles ur on  ur.id_usuario = us.id 
        WHERE us.documento='$documento'  limit 0,1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse = array('id' => $row["id"], 'nombre' => $row["nombre"], 'documento' => $row["documento"],);
            }
        } else {
            $reponse = "error";
        }

        return $reponse;
        $conn->close();
    }

    /**
     * 
     * @param type $id_usuario
     * @return string
     */
    public function usuario_archivos($id_usuario = '') {
        // Create connection

        $conn = Usuarios ::connect();
        $sql = "SELECT id_archivo,tipos_archivos,ruta,fecha_cargue from usuarios us "
                . "inner join archivos ar on ar.id_usuario = us.id "
                . "inner join tipos_archivos ta on ta.id_tipo_archivo = ar.tipo_archivo"
                . " WHERE us.id= '$id_usuario'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array('id_archivo' => $row["id_archivo"], 'tipos_archivos' => $row["tipos_archivos"], 'ruta' => $row["ruta"], 'fecha_cargue' => $row["fecha_cargue"]);
            }
        } else {
            $reponse = "error";
        }

        return $reponse;
        $conn->close();
    }

    /**
     * 
     * @param type $id_usuario
     * @param type $tipo_archivo
     * @param type $ruta
     * @return string
     */
    function registro_archivo($id_usuario = '', $tipo_archivo = '', $ruta = '') {
        // Create connection

        $conn = Usuarios::connect();
        $sql = " INSERT INTO archivos (id_usuario,ruta, tipo_archivo) "
                . "VALUES ('" . $id_usuario . "', '" . $ruta . "', '" . $tipo_archivo . "')";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

}

?> 