<?php

class Ips {

    const server = 'localhost';
    const username = 'root';
    const passs = '';
    const db = 'login_register_db';

    /**
     * 
     * @return \mysqli
     */
    static function connect() {


        $servername = self::server;
        $username = self::username;
        $password = self::passs;
        $dbname = self::db;

        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    /**
     * Consulta ips eps
     * @param type $id_eps
     * @return string
     */
    static function eps_ips($id_eps = '') {
        // Create connection

        $conn = Ips::connect();
        $sql = "SELECT ip.id_ips,ip.nombre,ip.direccion from ips ip 
               inner join    eps_ips  ei on ei.id_ips = ip.id_ips
		WHERE ei.id_eps='$id_eps' and ip.estado ='A'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array('id_ips' => $row["id_ips"], 'nombre' => $row["nombre"], 'direccion' => $row["direccion"]);
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @param type $nombre
     * @param type $apellido
     * @param type $tipo_doc
     * @param type $documento
     * @param type $email
     * @param type $password
     * @param type $ciudad
     * @param type $departamento
     * @param type $urbano_rural
     * @param type $notificaciones
     * @return string
     */
    function registro_dispensiario($nombre = '', $apellido = '', $tipo_doc = '', $documento = '', $email = '', $password = '', $ciudad = '', $departamento = '', $urbano_rural = '', $notificaciones = '') {
        // Create connection

        $conn = Registro::connect();
        $sql = "         INSERT INTO usuarios (nombre, apellido, tipo_doc, documento, email, password, ciudad, departamento, urbano_rural, notificaciones, estado)"
                . "VALUES ('" . $nombre . "', '" . $apellido . "', '" . $tipo_doc . "', '" . $documento . "', '" . $email . "', '" . $password . "', '" . $ciudad . "', '" . $departamento . "', '" . $urbano_rural . "', '" . $notificaciones . "', 'activo' )";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

}

?> 