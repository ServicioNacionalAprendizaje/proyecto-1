<?php

class Dispensiario {

    const server = 'localhost';
    const username = 'root';
    const passs = '';
    const db = 'login_register_db';

    function connect() {


        $servername = self::server;
        $username = self::username;
        $password = self::passs;
        $dbname = self::db;

        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    function dispensiario_eps($id_eps = '') {
        // Create connection

        $conn = Registro::connect();
        $sql = "SELECT ds.nombre,ds.direccion from dispensiario ds 
               inner join    eps_dispensiario  ed on ed.id_eps = ds.id_dispensiario
		WHERE ed.id_eps='$id_eps' and ds.estado ='A''";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $reponse = "registro id: " . $row["id"];
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    function registro_dispensiario($nombre = '', $apellido = '', $tipo_doc = '', $documento = '', $email = '', $password = '', $ciudad = '', $departamento = '', $urbano_rural = '', $notificaciones = '') {
        // Create connection

        $conn = Registro::connect();
        $sql = "         INSERT INTO usuarios (nombre, apellido, tipo_doc, documento, email, password, ciudad, departamento, urbano_rural, notificaciones, estado)"
                . "VALUES ('" . $nombre . "', '" . $apellido . "', '" . $tipo_doc . "', '" . $documento . "', '" . $email . "', '" . $password . "', '" . $ciudad . "', '" . $departamento . "', '" . $urbano_rural . "', '" . $notificaciones . "', 'activo' )";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

}

?> 