<?php

class Registro {

    const server = 'localhost';
    const username = 'root';
    const passs = '';
    const db = 'login_register_db';

    /**
     * 
     * @return \mysqli
     */
    function connect() {


        $servername = self::server;
        $username = self::username;
        $password = self::passs;
        $dbname = self::db;

        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    /**
     * 
     * @param type $documento
     * @param type $email
     * @return string
     */
    function consulta_usuario($documento = '', $email = '') {
        // Create connection

        $conn = Registro::connect();
        $sql = "SELECT * FROM  usuarios WHERE documento='$documento' or email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $reponse = array('id' => $row["id"]);
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @param type $nombre
     * @param type $apellido
     * @param type $tipo_doc
     * @param type $documento
     * @param type $email
     * @param type $password
     * @param type $ciudad
     * @param type $departamento
     * @param type $urbano_rural
     * @param type $notificaciones
     * @return string
     */
    function registro_usuario($nombre = '', $apellido = '', $tipo_doc = '', $documento = '', $email = '', $password = '', $ciudad = '', $departamento = '', $urbano_rural = '', $notificaciones = '') {
        // Create connection

        $conn = Registro::connect();
        $sql = "         INSERT INTO usuarios (nombre, apellido, tipo_doc, documento, email, password, ciudad, departamento, urbano_rural, notificaciones, estado)"
                . "VALUES ('" . $nombre . "', '" . $apellido . "', '" . $tipo_doc . "', '" . $documento . "', '" . $email . "', '" . $password . "', '" . $ciudad . "', '" . $departamento . "', '" . $urbano_rural . "', '" . $notificaciones . "', 'activo' )";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @param type $id_usuario
     * @return string
     */
    function registro_usuario_rol($id_usuario = '') {
        // Create connection

        $conn = Registro::connect();
        $sql = "         INSERT INTO usuarios_roles (id_usuario, id_rol, estado)"
                . "VALUES ('" . $id_usuario . "', '1', 'A' )";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

}

?> 