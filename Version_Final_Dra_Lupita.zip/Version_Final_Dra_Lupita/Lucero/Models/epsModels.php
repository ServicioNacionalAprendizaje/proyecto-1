<?php

class Eps {

    const server = 'localhost';
    const username = 'root';
    const passs = '';
    const db = 'login_register_db';

    /**
     * 
     * @return \mysqli
     */
    static function connect() {


        $servername = self::server;
        $username = self::username;
        $password = self::passs;
        $dbname = self::db;

        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }

    /*     * Consulta eps
     * 
     * @return string
     */

    static function eps() {
        // Create connection

        $conn = Eps::connect();
        $sql = "SELECT * FROM  eps WHERE estado='A'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array('id_eps' => $row["id_eps"], 'nombre_eps' => $row["nombre_eps"], 'nit' => $row["nit"], 'fecha_cargue' => $row["fecha_cargue"]);
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    /*     * Consulta especialidad
     *      * 
     * @return string
     */

    static function tipo_especialidad() {
        // Create connection

        $conn = Eps::connect();
        $sql = "SELECT * FROM login_register_db.tipos_especialides_medicas where estado='A'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array('id_tipos_medicos' => $row["id_tipos_medicos"], 'nombre' => $row["nombre"], 'tipo' => $row["tipo"], 'estado' => $row["estado"]);
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @param type $id_usuario
     * @return string
     */
    static function agendas_usuario($id_usuario = '') {
        // Create connection

        $conn = Eps::connect();
        $sql = "SELECT ag.id_agenda,tm.nombre as nombre_cita,nombre_eps,ip.nombre as nombre_ips,ip.direccion,dp.nombre as nombre_dis, dp.direccion as direccion_dis,ag.fecha_agenda
            FROM agendas ag
            inner join  eps ep on ep.id_eps = ag.id_eps
            inner join  ips ip on ip.id_ips = ag.id_ips
            inner join  tipos_especialides_medicas tm on tm.id_tipos_medicos = ag.id_especialidad
            inner join  dispensiario dp on dp.id_dispensiario = ag.id_dispensiario where id_usuario='$id_usuario'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array(
                    'id_agenda' => $row["id_agenda"],
                    'nombre_cita' => $row["nombre_cita"],
                    'nombre_eps' => $row["nombre_eps"],
                    'nombre_ips' => $row["nombre_ips"],
                    'direccion' => $row["direccion"],
                    'nombre_dis' => $row["nombre_dis"],
                    'direccion_dis' => $row["direccion_dis"],
                    'fecha_agenda' => $row["fecha_agenda"]
                );
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * Agendamiento de citas
     * @param type $id_usuario
     * @param type $eps
     * @param type $ips
     * @param type $dispensiario
     * @param type $cita
     * @param type $examen
     * @param type $fecha_agenda
     * @return string
     */
    static function registro_citas_examen($id_usuario = '', $eps = '', $ips = '', $dispensiario = '', $especialidad = '', $fecha_agenda = '') {
        // Create connection

        $conn = Eps::connect();
        $sql = "         INSERT INTO agendas ( id_usuario, id_eps, id_ips, id_dispensiario, id_especialidad, fecha_agenda,estado)"
                . "VALUES ( '" . $id_usuario . "', '" . $eps . "', '" . $ips . "', '" . $dispensiario . "', '" . $especialidad . "', '" . $fecha_agenda . "', 'A' )";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @param type $titulo
     * @param type $ruta_image
     * @param type $ruta
     * @return string
     */
    function registro_archivo_slide($titulo = '', $ruta_image = '', $ruta_archivo = '') {
        // Create connection

        $conn = Eps::connect();
        echo $sql = " INSERT INTO slide (titulo,ruta_image,ruta,estado) "
        . "VALUES ('" . $titulo . "','" . $ruta_image . "', '" . $ruta_archivo . "', 'A')";

        if ($conn->query($sql) === TRUE) {
            $reponse = "true";
        } else {
            $reponse = "errror";
        }

        $conn->close();

        return $reponse;
    }

    /**
     * 
     * @return string
     */
    function slide() {
        // Create connection

        $conn = Eps::connect();
        $sql = "SELECT * FROM  slide WHERE estado='A'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {

                $reponse[] = array(
                    'id_slide' => $row["id_slide"],
                    'titulo' => $row["titulo"],
                    'ruta_image' => $row["ruta_image"],
                    'ruta' => $row["ruta"],
                    'estado' => $row["estado"],
                    'fecha' => $row["fecha"],
                );
            }
        } else {
            $reponse = "";
        }

        $conn->close();

        return $reponse;
    }

}

?> 