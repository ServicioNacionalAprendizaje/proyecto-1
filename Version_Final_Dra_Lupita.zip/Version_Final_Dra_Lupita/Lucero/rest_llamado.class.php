<?php

error_reporting(E_ALL);

class CurlRequest {

    public function lineaHogar($cuenta = "", $tipo = "") {

        $url = "http://172.24.160.135:8080/EXP_WSCustomerRegistrationAPP/PS_WSCustomerRegistrationAPPV1.0_RS";
        //datos a enviar




        $data = array(
            "queryType" => "C",
            "value" => $cuenta,
        );
        $data = json_encode($data);

        $method = 'POST';
        $curl = curl_init();
        switch ($method) {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'system: WEB_APP_CLARO'
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        // EXECUTE:
        $result = curl_exec($curl);
        if (!$result) {
            die("Connection Failure");
        }
        curl_close($curl);
        return $result;
    }

    public function sendPost($cuenta = "", $tipo = "") {

        $url = "http://172.24.160.135:8080/EXP_WSPostActivation/PS_PostNetflixSubscriptionV1.0_RS/postNetflixSubscription";
        //datos a enviar

        if ($tipo == "1") {
            $origen = "Mobile";
        } else {
            $origen = "Fixed";
        }




        $data = array(
            "userReferenceId" => $cuenta,
            "serviceProvider" => "PA00003190",
            "serviceName" => "Netflix",
            "operatorId" => "COL",
            "userType" => "$origen",
            //"salesChannel" => "salesChannel",
            "operatorUrlError" => "https://www.miclaroapp.com.co/",
            "operatorAction" => "Activation",
            "extensionInfo" => array("item" => array(
                    array("key" => "ProductId", "value" => "1"),
                    array("key" => "subproductId", "value" => "0"),
                    array("key" => "Description", "value" => "servicio de netflix COL"),
                    array("key" => "typeServiceId", "value" => "4"),
                ))
        );
        $data = json_encode($data);

        $method = 'POST';
        $curl = curl_init();
        switch ($method) {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'channel: WEB_APP_CLARO',
            'xWsse:UsernameToken Username="PA00003190", PasswordDigest="!oTT3tCo"',
            'IpApplication:127.0.0.1"',
            'authorizationPath:WSSE realm="AMXHub", profile="UsernameToken"'
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        // EXECUTE:
        $result = curl_exec($curl);
        if (!$result) {
            die("Connection Failure");
        }
        curl_close($curl);
        return $result;
    }

    public function sendEmail($telefono = "", $url = "") {

        $url_ws = "http://172.24.232.150:8010/Notification/V2.0/Rest/PutMessage?TEMPLATE=RESOURCE";
        //datos a enviar

        if ($tipo = "1") {
            $origen = "Mobile";
        } else {
            $origen = "Fixed";
        }

        $texto = htmlspecialchars("Pronto llega medianoche y no te puedes perder de las mejores peliculas y series en Netflix. Ingresa a este link  $url y reactiva tu suscripcion y fresco que lo pagas en tu proxima factura Claro. Aplican TyC.", ENT_COMPAT, 'ISO-8859-1', true);

        $data = '{
          "headerRequest" : {
          "transactionId" : "2022060624510",
          "system" : "system432",
          "target" : "target",
          "user" : "user433",
          "password" : "password434",
          "requestDate" : "2022-05-24T11:29:01.410",
          "ipApplication" : "SMS_FS_TCRM1",
          "traceabilityId" : "traceabilityId436"
          },

          "message" : "{\"pushType\": \"SINGLE\",\"typeCostumer\": \"9F1AA44D-B90F-E811-80ED-FA163E10DFBE\",\"messageBox\": [ { \"messageChannel\": \"SMS\", \"messageBox\": [{ \"customerBox\": \"' . $telefono . '\"} ] }],\"profileId\":[\"NETFLIXAPP\"],\"communicationType\": [ \"REGULATORIO\"],\"communicationOrigin\": \"TCRM\",\"deliveryReceipts\": \"NO\",\"contentType\": \"MESSAGE\",\"messageContent\": \"' . $texto . ' \" }"
          }';

        $method = 'PUT';
        $curl = curl_init();
        switch ($method) {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            default:
                if ($data)
                    $url_ws = sprintf("%s?%s", $url_ws, http_build_query($data));
        }
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url_ws);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        // EXECUTE:
        $result = curl_exec($curl);
        if (!$result) {
            die("Connection Failure");
        }
        curl_close($curl);
        return $result;
    }

    public function sendSms($telefono = "", $url = "") {

        var_dump($telefono);

        $url_ws = "http://172.24.232.150:8010/Notification/V2.0/Rest/PutMessage?TEMPLATE=RESOURCE";
        //datos a enviar
        //$texto = htmlspecialchars("Pronto llega medianoche y no te puedes perder de las mejores peliculas y series en Netflix. Ingresa a este link  $url y reactiva tu suscripcion y fresco que lo pagas en tu proxima factura Claro. Aplican TyC.", ENT_COMPAT, 'ISO-8859-1', true);
        $texto = htmlspecialchars("Espera, espera! Reactiva tu suscripcion a Netflix y continua disfrutando de las series y películas de temporada. Ingresa a este link ( http://bit.ly/3Xhlkm1 ) y sigue disfrutando con Claro y la red #1 en cobertura 4G. Aplican TyC.", ENT_COMPAT, 'ISO-8859-1', true);

        $data = '{
          "headerRequest" : {
          "transactionId" : "2022060624510",
          "system" : "system432",
          "target" : "target",
          "user" : "user433",
          "password" : "password434",
          "requestDate" : "2022-05-24T11:29:01.410",
          "ipApplication" : "SMS_FS_TCRM1",
          "traceabilityId" : "traceabilityId436"
          },

          "message" : "{\"pushType\": \"SINGLE\",\"typeCostumer\": \"9F1AA44D-B90F-E811-80ED-FA163E10DFBE\",\"messageBox\": [ { \"messageChannel\": \"SMS\", \"messageBox\": [{ \"customerBox\": \"' . $telefono . '\"} ] }],\"profileId\":[\"NETFLIXAPP\"],\"communicationType\": [ \"REGULATORIO\"],\"communicationOrigin\": \"TCRM\",\"deliveryReceipts\": \"NO\",\"contentType\": \"MESSAGE\",\"messageContent\": \"' . $texto . ' \" }"
          }';

        $method = 'PUT';
        $curl = curl_init();
        switch ($method) {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            default:
                if ($data)
                    $url_ws = sprintf("%s?%s", $url_ws, http_build_query($data));
        }
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url_ws);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json'
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        // EXECUTE:
        $result = curl_exec($curl);
        if (!$result) {
            die("Connection Failure");
        }
        curl_close($curl);
        return $result;
    }

    /*     * ************************************************************************* ******************************************************************** */
    /*     * ************************************************************************* ******************************************************************** */

    /*     * COMEINZA PROCESAMIENTO DE DATOS*** */

    /**
     * 
     * @param type $arreglo
     * @param type $ruta
     * @param type $delimitador
     * @param type $encapsulador
     */
    public function generarCSV_stand($arreglo, $ruta, $delimitador, $encapsulador) {
        $file_handle = fopen($ruta, 'w');
        foreach ($arreglo as $linea) {
            fputcsv($file_handle, $linea, $delimitador, $encapsulador);
        }
        rewind($file_handle);
        fclose($file_handle);
    }

    /**
     * 
     * @param type $tipo
     * @param type $tamanio
     * @param type $archivotmp
     */
    public function procesa_csv_stand($tipo, $tamanio, $archivotmp) {

        //cargamos el archivo
        $lineas = file($archivotmp);

//inicializamos variable a 0, esto nos ayudará a indicarle que no lea la primera línea
        $i = 0;
        $trans_hub[] = array("CUENTA;ENVIO");

        foreach ($lineas as $linea_num => $linea) {
            if ($i != 0) {
                $datos = explode(";", $linea);
                $cuenta = utf8_encode(trim($datos[0]));
                $cuenta_log = $cuenta;
                $tipo = utf8_encode(trim($datos[1]));

                //$resultado = CurlRequest::sendPost($cuenta, $tipo);
                //$resultado = json_decode($resultado);
                //$url = isset($resultado->url) ? $resultado->url : "";
                $url = "ok";

                if ($url != "") {
                    if ($tipo == "2") {
                        $datos_cuenta = CurlRequest::lineaHogar($cuenta);
                        $datos_cuenta = json_decode($datos_cuenta);
                        $cuenta = isset($datos_cuenta->data->mobileList->msisdn[0]) ? $datos_cuenta->data->mobileList->msisdn[0] : "";
                    }

                    if ($cuenta != "") {
                        $send_sms = CurlRequest::sendSms($cuenta, $url);
                        $send_sms = json_decode($send_sms);

                        $send_sms = isset($send_sms->isValid) ? $send_sms->isValid : "";

                        if ($send_sms == "true") {
                            $trans_hub[] = array($cuenta_log . ";ok");
                        } else {
                            $trans_hub[] = array($cuenta_log . ";error_sms");
                        }
                    } else {
                        $trans_hub[] = array($cuenta_log . ";error_linea_hogar");
                    }
                } else {

                    $trans_hub[] = array($cuenta_log . ";error_elegibilidad");
                }
            }
            $i++;
        }
        /* echo "<pre>";
          var_dump($trans_hub);
          die(); */
        $ruta = "./REPORTE_STAND_HUB.CSV";
        CurlRequest::generarCSV_stand($trans_hub, $ruta, $delimitador = ';', $encapsulador = '"');
    }

    public function procesa_stand_notficacion($cuenta = "", $tipo = "") {
        $trans_hub = array();
        $cuenta_log = $cuenta;
        $resultado = CurlRequest::sendPost($cuenta, $tipo);
        $resultado = json_decode($resultado);
        $url = isset($resultado->url) ? $resultado->url : "";
        $url = "a";

        if ($url != "") {
            if ($tipo == "2") {
                $datos_cuenta = CurlRequest::lineaHogar($cuenta);
                $datos_cuenta = json_decode($datos_cuenta);
                $cuenta = isset($datos_cuenta->data->mobileList->msisdn[0]) ? $datos_cuenta->data->mobileList->msisdn[0] : "";
            }

            if ($cuenta != "") {
                $send_sms = CurlRequest::sendSms($cuenta, $url);
                $send_sms = json_decode($send_sms);

                $send_sms = isset($send_sms->isValid) ? $send_sms->isValid : "";

                if ($send_sms == "true") {
                    $trans_hub[] = array($cuenta_log . ";ok");
                } else {
                    $trans_hub[] = array($cuenta_log . ";error_sms");
                }
            } else {
                $trans_hub[] = array($cuenta_log . ";error_linea_hogar");
            }
        } else {

            $trans_hub[] = array($cuenta_log . ";error_elegibilidad");
        }

        return $trans_hub;
    }

    public function procesa_stand($cuenta = "", $tipo = "") {
        $trans_hub = array();
        $cuenta_log = $cuenta;
        $resultado = CurlRequest::sendPost($cuenta, $tipo);
        $resultado = json_decode($resultado);

        $url = isset($resultado->url) ? $resultado->url : "";

        if ($url != "") {

            echo "URL GENERADA: " . $url;
        } else {
            echo $resultado->errorcode . " - " . $resultado->description;
        }
    }

}
