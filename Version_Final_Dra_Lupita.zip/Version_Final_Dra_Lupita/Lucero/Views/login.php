<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name ="viewport" content="width=device-width, initial-scale=1.0">
        <title> Login y Registro</title>

        <link rel="stylesheet" href="./style/estilos.css">
        <meta charset="utf-8">

        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Custom styles for this template -->

        <script type='text/javascript' src='../js/jquery_min.js'></script>
        <script type='text/javascript' src='../js/jquery.form.js'></script>
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">



        <title>jQuery UI Tabs - Default functionality</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>

    </head>

    <body style="background-image: url(./../image/lupitalogin.jpg)">

        <Main>

            <div class="contenedor__todo">

                <div class="caja__trasera">
                    <div class="caja__trasera-login">
                        <h3>¿Ya tienes cuenta?</h3>
                        <p>Inicia sesion para ingresar a opciones de paciente</p>
                        <button id="btn__iniciar-sesion">Iniciar sesion</button>
                    </div>

                    <div class="caja__trasera-register">
                        <h3>¿Aun no tienes cuenta?</h3>
                        <p>Registrate para que puedas iniciar sesion</p>
                        <button id="btn__registrarse">Registrarse</button>      <!--  <a href="registro.php"></a>-->
                    </div>

                </div>


                <!-- formulario de login y registro-->

                <!--<div class="contenedor__login-register">
   
             

                <form id="frmLogin" action="valida_login.php" method="post" class="formulario__login">
                    <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                    <p><div class="mensagem-erro"></div></p>
                    <h2> Iniciar Sesion</h2>
                    <input type="text" placeholder="Correo Electronico" class="form-control" id="correo" name="correo">
                    <input type="password" placeholder="Ingrese su Contraseña" name="contrasena" id="contrasena" name="contrasena" >
                    <button>Entrar</button>
                </form>

                <!--registro-->


                <div class="contenedor__login-register">

                    <!-- login-->

                    <form id="form_login" method="POST" class="formulario__login">
                        <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                        <p><div class="mensagem-erro"></div></p>
                        <h2> Iniciar Sesion</h2>
                        <input type="text" placeholder="Correo Electronico" class="form-control" id="correo" name="correo" maxlength="30">
                        <input type="password" placeholder="Ingrese su Contraseña" name="contrasena" id="contrasena" name="contrasena"  maxlength="30">
                        <button>Entrar</button>
                    </form>

                    <!--registro-->

                    <form id="form_registro"  method="POST" class="formulario__register">
                        <h2>Registrarse</h2>
                        <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                        <div class="mensagem-erro"></div>
                        <!--COLUMNAS-->
                        <input type="text" name="nombre" id="nombre" value="" placeholder="Nombre Completo *" maxlength="20" >
                        <input type="text" name="apellido" id="apellido"  placeholder="Apellido *" value="" maxlength="20" >
                        <br>
                        <div style="width: 100%" >Tipo Doc *
                            <select name="tipo_doc" id="tipo_doc" placeholder="Apellido"style="width: 70%;float: right">
                                <option value="cc">Cedula</option>
                                <option value="nit">Nit</option>
                            </select>
                        </div>
                        <input type="text" name="documento" id="documento" placeholder="Documento *" maxlength="10" value="">
                        <input type="text" name="email" id="email" value="" placeholder="Emalil *" maxlength="30" >
                        <input type="text" name="password" id="password" value="" placeholder="Password *" maxlength="30" ><br>
                        <input type="text" name="ciudad" id="ciudad" value="" placeholder="Ciudad *">
                        <input type="text" name="departamento" id="departamento" value="" placeholder="Departamento *">
                        <div style="width: 100%;" >
                            <div style="width:50% ;float: left" ><h5>Urbano</h5><input type="radio" name="urb_rur" id="urb_rur" value="urbano"></div>
                            <div style="width:50% ;float: left" ><h5>Rural</h5><input type="radio" name="urb_rur" id="urb_rur" value="rural"></div>
                        </div>
                        <div style="width: 100%;" >
                            <div style="width: 100%;" ><h4>Notificaciones</h4></div>
                            <div style="width: 33%;float: left" ><h5>Correo</h5><input type="checkbox" name="n_email" id="n_email" value="email"></div> 
                            <div style="width: 33%;float: left" ><h5>Whatsapp</h5><input type="checkbox" name="n_whatsapp" id="n_whatsapp" value="whatsapp"></div>
                            <div style="width: 33%;float: left" ><h5>Sms</h5><input type="checkbox" name="sms" id="n_sms" value="n_sms"> </div>
                        </div>
                        <input type="text" name="evento" id="evento" value="registro_usuario" style="visibility:hidden"><br>
                        <input type="submit" name="guardar" id="guardar" value="Guardar"><br>
                    </form>
                </div>
            </div>
        </Main>

        <script src="../js/script.js"></script>
        <script type="text/javascript">



            $(document).ready(function () {

                /***
                 * ajax login
                 */

                $('#form_login').submit(function (e) {
                    console.log($('#correo').val());
                    $('div.mensagem-erro').html('');
                    // Mostrando carga
                    $('div.loader').show();

                    if ($('#correo').val() == '' || $('#contrasena').val() == '') {

                        $('div.loader').hide();
                        $('div.mensagem-erro').html('correo y contraseña son obligatorios');
                        return false;
                    }
                    e.preventDefault();
                    const data = {
                        correo: $('#correo').val(),
                        contrasena: $('#contrasena').val(),

                    };

                    $.ajax({
                        type: 'POST',
                        url: 'valida_login.php',
                        data: JSON.stringify(data),
                        contentType: 'application/json',
                    })
                            .done((data) => {
                                obj = JSON.parse(data);
                                respuesta = obj.respuesta;
                                // Si no hay error mostrar el siguiente archivo
                                if (respuesta == 'true') {

                                    window.location.replace("index.php");
                                    //window.location.href = 'index.php';
                                } else
                                {
                                    // Encondiendo la carga con hide()
                                    $('div.loader').hide();
                                    // Exibimos mensaje de error
                                    $('div.mensagem-erro').html(respuesta);
                                }


                            })
                            .fail((err) => {
                                console.error(err);
                            })
                            .always(() => {
                                console.log('always called');
                            });
                });

                /***
                 * ajax registro
                 */
                $('#form_registro').submit(function (e) {

                    e.preventDefault();
                    const data = {
                        nombre: $('#nombre').val(),
                        apellido: $('#apellido').val(),
                        tipo_doc: $('#tipo_doc').val(),
                        documento: $('#documento').val(),
                        email: $('#email').val(),
                        password: $('#password').val(),
                        ciudad: $('#ciudad').val(),
                        departamento: $('#departamento').val(),
                        urb_rur: $('#urb_rur').val(),
                        notificacion: $('#n_email').val() + ',' + $('#n_whatsapp').val() + ',' + $('#n_sms').val(),
                        evento: $('#evento').val(),
                    };

                    console.log($('#nombre').val());
                    if ($('#nombre').val() == '' ||
                            $('#apellido').val() == '' ||
                            $('#tipo_doc').val() == '' ||
                            $('#documento').val() == '' ||
                            $('#email').val() == '' ||
                            $('#password').val() == '' ||
                            $('#ciudad').val() == '' ||
                            $('#departamento').val() == '') {

                        $('div.loader').hide();
                        $('div.mensagem-erro').html('Los campos marcados con * son obligatorios');
                        return false;
                    }

                    $.ajax({
                        type: 'POST',
                        url: '../Controllers/registroController.php',
                        data: JSON.stringify(data),
                        contentType: 'application/json',
                    })
                            .done((data) => {
                                $('div.loader').hide();
                                $('div.mensagem-erro').html(data);
                                $('input').val("");
                            })
                            .fail((err) => {
                                console.error(err);
                            })
                            .always(() => {
                                console.log('always called');
                            });
                });



            });
            $(".tab-list").on("click", ".tab", function (event) {
                event.preventDefault();
                $(".tab").removeClass("active");
                $("#form:input").prop("disabled", true);
                $('.input').val('');
                $(".tab-content").removeClass("show");
                $(this).addClass("active");
                $('.input').val('');
                $("#form:input").prop("disabled", false);
                $($(this).attr('href')).addClass("show");
            });

        </script>
    </body>
</html>

