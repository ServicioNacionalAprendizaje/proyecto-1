
<?php
require_once( "../class/login.class.php");
require_once( "../class/../Models/epsModels.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;
/* Cargo eps existentes */
$eps = Eps::eps();
$tipo_especialidad = Eps::tipo_especialidad();
$agendas_usuario = Eps::agendas_usuario($_SESSION['id_usuario']);

//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>

<html> 
    <head> 
        <link rel="stylesheet" href="./style/style.css">
        <meta http-equiv="content-type" content="text/html;
              charset = ISO-8859-1">
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <title>Eps-Usuario</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>
        <script src="../js/datetimepicker/moment.min.js"></script>
        <link href="../js/datetimepicker/jquery.datetimepicker.min.css" rel="stylesheet"/>
        <script src="../js/datetimepicker/jquery.datetimepicker.full.min.js"></script>
        <script>
            $(function () {
                $("#tabs").tabs();
            });
        </script>
    </head>
    <div style="width: 700px">
        <div style="width:99%;" >
            <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;text-align: right""><a href="index.php"><img  style="margin: 0px" src="../image/home.png" width="40px"height="40px"/></a></div>
        </div>
        <br>
        <br>
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">Eps - usuario</a></li>

            </ul>
            <div id="tabs-1" class="tab-content show">

                <form method="POST" action="../Controllers/epsusuarioController.php" enctype="multipart/form-data">
                    <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                    <p><div class="mensagem-erro"></div></p>
                    <input type="text" id="evento" name="evento"  value="agendar_citas_examen" style="display: none" />
                    <input type="text" id="cedula_return" name="cedula_return" readonly="readonly" style="display: block"  value="<?php echo $_SESSION['cedula'] ?>"/>
                    <input type="text" id="nombre_search" name="nombre_search" readonly="readonly" style="display: block" value="<?php echo $_SESSION['nombre'] ?>" />
                    <input type="text" id="url_return" name="url_return" readonly="readonly" style="display: none" value="eps_usuario.php" />
                    <br>
                    <div style="width: 50%;float: left;" >Seleccione Eps</div>
                    <div style="width: 50%;float: left;"><select name="eps" id="eps" onchange="">
                            <option value="">--seleccione--</option>
                            <?php
                            for ($i = 0; $i < count($eps); $i++) {
                                echo "<option value='" . $eps[$i]['id_eps'] . "'>" . $eps[$i]['nombre_eps'] . "</option>";
                            }
                            ?>
                        </select><br></div>


                    <div style="width: 50%;float: left;" >Ips <select name="ips" id="ips"></select></div>
                    <div style="width: 50%;float: left;" >  Dispensiario <select name="dispensiario" id="dispensiario"></select></div>
                    <br>
                    <div>Seleccione una opcion <br>
                        Cita Medica <input type="radio" class="tipo_cita" id="tipo_cita"  name="tipo_cita" onclick="tipo_examen(this.value)" value="cita" >
                        Examen medico <input type="radio" class="tipo_cita"  id="tipo_cita" name="tipo_cita"onclick="tipo_examen(this.value)" value="examen">
                    </div>
                    <div id="div_cita" style="display: none;display: none;width: 100%;">Cita medica
                        <select name="cita" id="cita">
                            <?php
                            for ($i = 0; $i < count($tipo_especialidad); $i++) {
                                if ($tipo_especialidad[$i]['tipo'] == 'cita') {
                                    echo "<option value='" . $tipo_especialidad[$i]['id_tipos_medicos'] . "'>" . $tipo_especialidad[$i]['nombre'] . "</option>";
                                }
                            }
                            ?>
                        </select><br>
                    </div>
                    <div id="div_examen" style="display: none;width: 100%;float: left;">Examen medico
                        <select name="examen" id="examen">   
                            <?php
                            for ($a = 0; $a < count($tipo_especialidad); $a++) {
                                if ($tipo_especialidad[$a]['tipo'] == 'examen') {
                                    echo "<option value='" . $tipo_especialidad[$a]['id_tipos_medicos'] . "'>" . $tipo_especialidad[$a]['nombre'] . "</option>";
                                }
                            }
                            ?></select>
                        <br>
                    </div>
                    <div id="div_examen" style="width: 100%;float: left;"><p>Fecha:
                            <input type="text" id="picker1" name="fecha_agenda"><img src="../image/calendario.png" width="25px"height="25px"/></p>
                    </div>

                    <button>Guardar</button>
                </form>
                <div>Citas o examenes</div>
                <div id="detalleseleccion" name="detalleseleccion" style="overflow-x: hidden; overflow-y: auto; height: 16em; border: 1px solid"><p>                

                    <table>

                        <tr>
                            <td>id</td>
                            <td>Detalle Cita</td>
                            <td>Eps</td>
                            <td>Ips</td>  
                            <td>Direccion</td>
                            <td>Dispensiario</td> 
                            <td>Direccion</td> 
                            <td>Fecha</td> 
                        </tr>
                        <tbody id="tabla_tr">
                            <?php
                            if ($agendas_usuario != '') {
                                for ($i = 0; $i < count($agendas_usuario); $i++) {

                                    echo "<tr>"
                                    . "<td>" . $agendas_usuario[$i]['id_agenda'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['nombre_cita'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['nombre_eps'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['nombre_ips'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['direccion'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['nombre_dis'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['direccion_dis'] . "</td>"
                                    . "<td>" . $agendas_usuario[$i]['fecha_agenda'] . "</td>"
                                    . "</tr>";
                                }
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</html>

<script type="text/javascript">



    jQuery.datetimepicker.setDateFormatter({
        parseDate: function (date, format) {
            var d = moment(date, format);
            return d.isValid() ? d.toDate() : false;
        },
        formatDate: function (date, format) {
            return moment(date).format(format);
        }
    });

    $("#picker1").datetimepicker({
        minDate: 0,
        minTime: '06:00',
        maxTime: '18:00',
        step: 30,
        format: 'YYYY/MM/DD H:mm',
        formatTime: 'H:mm',
        formatDate: 'YYYY/MM/DD'
    });
//try to use different date format

    /*SHOW EXAMEN*/
    function tipo_examen(tp_examen) {
        console.log(tp_examen);
        if (tp_examen == "cita") {
            $("#div_examen").hide();
            $("#div_cita").show();
        }
        if (tp_examen == "examen") {
            $("#div_examen").show();
            $("#div_cita").hide();
        }

    }
    $(document).ready(function () {
        /**CARGO FECHA*/
        /* $("#datepicker").datepicker({
         format: 'Y-m-d H:i',
         minDate: 0
         //maxDate: "+10D"
         });*/
        /*EJECUTO BUSQUEDA EPS*/
        $('#eps').change(function (e) {
            $("#ips").empty('');
            $("#dispensiario").empty('');
            const data = {
                id_eps: $('#eps').val(),
                evento: 'consulta_ips_dispensiario'
            };
            $.ajax({
                type: 'POST',
                url: '../Controllers/epsusuarioController.php',
                data: JSON.stringify(data),
                contentType: 'application/json',
            }).done((data) => {
                var obj = jQuery.parseJSON(data);
                console.log(obj);
                if (typeof obj.error != "undefined") {
                    console.log(obj.error);
                    $('div.loader').hide();
                    $('div.mensagem-erro').html(obj.error);
                } else {

                    td_ips = "";
                    td_dispensiario = "";
                    console.log(obj);
                    for (i = 0; i < obj.ips.length; i++) {
                        td_ips += "<option value='" + obj.ips[i]['id_ips'] + "'>";
                        td_ips += "" + obj.ips[i]['nombre'] + "";
                        td_ips += "-" + obj.ips[i]['direccion'] + "</option>";
                    }

                    for (z = 0; z < obj.dispensiario.length; z++) {
                        td_dispensiario += "<option value='" + obj.dispensiario[z]['id_dispensiario'] + "'>";
                        td_dispensiario += "" + obj.dispensiario[z]['nombre'] + "";
                        td_dispensiario += "-" + obj.dispensiario[z]['direccion'] + "</option>";
                    }

                    $("#ips").append(td_ips);
                    $("#dispensiario").append(td_dispensiario);
                }


            }).fail((err) => {
                console.error(err);
            }).always(() => {
                console.log('always called');
            });
        });
    }
    );
    $(".tab-list").on("click", ".tab", function (event) {
        event.preventDefault();
        $(".tab").removeClass("active");
        $("#form:input").prop("disabled", true);
        $('.input').val('');
        $(".tab-content").removeClass("show");
        $(this).addClass("active");
        $('.input').val('');
        $("#form:input").prop("disabled", false);
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
