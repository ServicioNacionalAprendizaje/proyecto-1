
<?php
require_once( "../class/login.class.php");
require_once( "../class/../Models/epsModels.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;

//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>

<html> 
    <head> 
        <link rel="stylesheet" href="./style/style.css">
            <link rel="stylesheet" href="./style/slider.css">
                <meta http-equiv="content-type" content="text/html;
                      charset = ISO-8859-1">
                    <script src="../js/jquery_min.js"></script>
                    <script src="../js/jquery_1.11.js"></script>


                    <title>Especialista Usuario</title>
                    <link rel="stylesheet" href="./style/jquery-ui.css">

                        <script src="../js/jquery-3.7.1.js"></script>
                        <script src="../js/jquery-ui.js"></script>
                        <script>
                            $(function () {
                                $("#tabs").tabs();
                            });
                        </script>
                        </head>
                        <div style="width: 900px;height: 900px">
                            <div style="width:99%;" >
                                <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
                                <div style="width: 33%; float: left;"></div>
                                <div style="width: 33%; float: right;text-align: right"><a href="index.php"><img style="margin: 0px" src="../image/home.png" width="40px"height="40px"/></a></div>
                            </div>
                            <br>
                                <br>
                                    <div id="tabs">
                                        <ul>
                                            <li><a href="#tabs-1">Manejo -Enfermedades</a></li>

                                        </ul>
                                        <!-- <div id="tabs-1" class="tab-content show">-->
                                        <div class="wrapper-slider-news">
                                            <div class="SliderNews">
                                                <div class="SliderComplete">
                                                    <ul class="slider">
                                                        <?php
                                                        $modelUsuario = new Eps();
                                                        $response_archivos = $modelUsuario->slide();
                                                        if ($response_archivos != '') {
                                                            for ($i = 0; $i < count($response_archivos); $i++) {
                                                                echo "<li><a>"
                                                                . "<img src='image_slide/" . $response_archivos[$i]['ruta_image'] . "' style='width: 100px; height: 100px'>"
                                                                . "<p><a href='./Files_slide/". $response_archivos[$i]['ruta'] . "' target='a_blank'>" . $response_archivos[$i]['titulo'] . "</a></p>"
                                                                . "<p><a href ='./Files_slide/" . $response_archivos[$i]['ruta'] . "'  target='_blank'>Descargar</td>"
                                                                . "<p><a href='#'>" . $response_archivos[$i]['fecha'] . "</a></p>";
                                                            }
                                                        }
                                                        ?>
                                                        <!--  <li>
                                                              <a>
                                                                  <img src="../image/Beach.png" style="width: 60px; height: 60px">
                                                                  <p><a href="Files_enfermedades/diabetes.pdf" target="a_blank">Manejo Diabetes</a> 09-08-2024</p>
                                                                  <p><a href="#">BMixer</a></p>
                                                              </a>
                                                          </li>-->

                                                    </ul>
                                                </div>
                                                <button title="before" class="close">
                                                    <svg version="1.1" id="left" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                         viewBox="12.7 2.5 15.4 25" enable-background="new 12.7 2.5 15.4 25" height="24" xml:space="preserve">
                                                        <g id="chevron-right">
                                                            <polygon fill="#38373A" points="13,15 25,27 27.8,24.2 18.6,15 27.8,5.8 25,3 	"/>
                                                        </g>
                                                    </svg>
                                                </button>
                                                <button title="after" class="open">
                                                    <svg version="1.1" id="right" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                         viewBox="12.7 2.5 15.4 25" enable-background="new 12.7 2.5 15.4 25" height="24" xml:space="preserve">
                                                        <g id="chevron-right">
                                                            <polygon fill="#38373A" points="15.8,3 13,5.8 22.2,15 13,24.2 15.8,27 27.8,15 	"/>
                                                        </g>
                                                    </svg>
                                                </button>
                                            </div>

                                            <!--   </div>-->

                                        </div>
                                    </div>
                                    </div>

                                    </html>

                                    <script type="text/javascript">


                                        $(document).ready(function () {

                                            $(function () {
                                                $('button').click(function () {
                                                    $(this).parents('.SliderNews').children('button').removeClass('close').fadeIn(300);
                                                    $(this).addClass('close').fadeOut(300);
                                                    $(this).parents('.SliderNews').children('.SliderComplete').children('.slider').toggleClass('turn');
                                                });
                                            });
                                        });


                                        $(".tab-list").on("click", ".tab", function (event) {
                                            event.preventDefault();
                                            $(".tab").removeClass("active");
                                            $("#form:input").prop("disabled", true);
                                            $('.input').val('');
                                            $(".tab-content").removeClass("show");
                                            $(this).addClass("active");
                                            $('.input').val('');
                                            $("#form:input").prop("disabled", false);
                                            $($(this).attr('href')).addClass("show");
                                        });

                                    </script>




                                    </html>
