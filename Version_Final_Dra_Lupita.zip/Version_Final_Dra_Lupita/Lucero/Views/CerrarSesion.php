<?php

require_once( "../class/login.class.php");
// Instancia el objeto da classe Login
$objLogin = new Login();

// Finaliza la sessión del usuario
$objLogin->logout('login.php');
?>
