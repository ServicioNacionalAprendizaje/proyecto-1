
<?php
require_once( "../class/login.class.php");
require_once( "../class/../Models/usuariosModels.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;

//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>

<html> 
    <head> 
        <link rel="stylesheet" href="./style/style.css">
        <meta http-equiv="content-type" content="text/html;
              charset = ISO-8859-1">
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <title>Especialista Usuario</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>
        <script>
            $(function () {
                $("#tabs").tabs();
            });
        </script>
    </head>
    <div style="width: 800px">
        <div style="width:99%;" >
            <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;text-align: right"><a href="index.php"><img style="margin: 0px" src="../image/home.png" width="40px"height="40px"/></a></div>
        </div>
        <br>
        <br>
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">Usuario</a></li>

            </ul>
            <div id="tabs-1" class="tab-content show">

                <div style="width: 100%;float: left;">
                    <div style="width: 55%;float: left;">
                        <textarea name="textarea" rows="10" cols="45" style="resize: none;">Sera atendido en breve por un especialista de salud....</textarea><!-- comment -->
                    </div>    
                    <div style="width: 45%;float: right;text-align: right">
                        <div style="width: 100%;"><img src="../image/PABLO-ASESOR-EN-LINEA--700x590.png" style="width: 30%; height:10 auto;" alt=""></div>
                        <img  src="../image/whatsapp.png" alt="Bootstrap" width="32" height="32"></button>
                        <a href="https://wa.me/0573005370550" target="_blank">¡Chatea con nosotros en WhatsApp!</a>  

                    </div>
                </div>

                <form method="POST" action="../Controllers/archivosController.php" enctype="multipart/form-data">
                    <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                    <p><div class="mensagem-erro"></div></p>

                    Hola:
                    <input type="text" id="evento" name="evento"  value="carga_archivo_usuario" style="display: none" />
                    <input type="text" id="cedula_return" name="cedula_return" readonly="readonly" style="display: block"  value="<?php echo $_SESSION['cedula'] ?>"/>
                    <input type="text" id="nombre_search" name="nombre_search" readonly="readonly" style="display: block" value="<?php echo $_SESSION['nombre'] ?>" />
                    <input type="text" id="url_return" name="url_return" readonly="readonly" style="display: none" value="especialista_usuario.php" />
                    <br>
                    Tipo Examen<select name="tipo_examen" id="tipo_examen">
                        <option value="1">Análisis de orina.</option>
                        <option value="2">Análisis de sangre.</option>
                        <option value="3">Pruebas de laboratorio.</option>
                        <option value="4">Pruebas y exámenes para la tiroides.</option>
                        <option value="5">Pruebas y exámenes para los riñones.</option>
                        <option value="6">Historia Clinica.</option>

                    </select><br>
                    <div>
                        <span>Adjuntar Examenes:</span>
                        <input type="hidden" name="MAX_FILE_SIZE" value="5000000">
                        <br>
                        <br>
                        <b>Enviar un nuevo archivo: </b>
                        <br>
                        <input name="userfile" type="file">
                        <br>
                        <input type="submit" value="Cargar Documento">
                    </div>
                    <div class="container-fluid row">
                        <div class="col-12 align-self-start">
                            <p>Documentos Usuario</p>
                        </div>
                        <div id="detalleseleccion" name="detalleseleccion" style="overflow-x: hidden; overflow-y: auto; height: 16em; border: 1px solid"><p>                

                            <table>

                                <tr>
                                    <td>id</td>
                                    <td>Nombre Examen</td>
                                    <td>Archivo</td>  
                                    <td>Fecha</td> 
                                </tr>
                                <tbody id="tabla_tr">
                                    <?php
                                    $modelUsuario = new Usuarios();
                                    $response_archivos = $modelUsuario->usuario_archivos($_SESSION['id_usuario']);
                                    if ($response_archivos != 'error') {
                                        for ($i = 0; $i < count($response_archivos); $i++) {
                                            echo "<tr>"
                                            . "<td>" . $response_archivos[$i]['id_archivo'] . "</td>"
                                            . "<td>" . $response_archivos[$i]['tipos_archivos'] . "</td>"
                                            . "<td><a href ='./files/" . $response_archivos[$i]['ruta'] . "'  target='_blank'>Descargar</td>"
                                            . "<td>" . $response_archivos[$i]['fecha_cargue'] . "</td></tr>";
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>

</html>

<script type="text/javascript">


    $(document).ready(function () {


    });


    $(".tab-list").on("click", ".tab", function (event) {
        event.preventDefault();
        $(".tab").removeClass("active");
        $("#form:input").prop("disabled", true);
        $('.input').val('');
        $(".tab-content").removeClass("show");
        $(this).addClass("active");
        $('.input').val('');
        $("#form:input").prop("disabled", false);
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
