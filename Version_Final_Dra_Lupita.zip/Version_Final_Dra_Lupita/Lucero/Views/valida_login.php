<?php

// Incluimos fichero de conexion

require_once("../class/login.class.php");

// Instancia del objeto classe Login
$objLogin = new Login();

// Recuperando informacion del formulario

$data = json_decode(file_get_contents('php://input'), true);

$correo = $data['correo'];
$contrasena = hash("sha512", $data['contrasena']);

// Usuario corecto
if ($objLogin->logar($correo, $contrasena)) {
    echo json_encode(array("respuesta" => "true"));
} else {
    echo json_encode(array("respuesta" => "Usuario y contraseña invalidas"));
// Retornando mensaje de error
}
?>
