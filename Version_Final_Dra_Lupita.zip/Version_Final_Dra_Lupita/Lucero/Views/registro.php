<html>
    <head> 

        <link rel="stylesheet" href="./style/style.css">
        <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <title>jQuery UI Tabs - Default functionality</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>
        <script>
            $(function () {
                $("#tabs").tabs();
            });
        </script>
    </head>
    <div style="width: 600px">
        <div>
            <div style="width: 33%;float: left;"></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;"><a href="login.php"><img src="../image/home.png" width="40px"height="40px"/></a></div>
        </div>
        <br>
        <br>
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">Especialista</a></li>
            </ul>

            <div id="tab-1" class="tab-content show">
                <form method="post"  id="form_registro" type="submit" >
                    <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                    <p><div class="mensagem-erro"></div></p>
                    <!--COLUMNAS-->
                    Nombre <input type="text" name="nombre" id="nombre" value="" >*<br>
                    Apellido <input type="text" name="apellido" id="apellido" value="">*<br>
                    Tipo Documento 
                    <select name="tipo_doc" id="tipo_doc">
                        <option value="cc">Cedula</option>
                        <option value="nit">Nit</option>
                    </select>*<br>
                    Documento <input type="text" name="documento" id="documento" value="">*<br>
                    Email<input type="text" name="email" id="email" value="">*<br>
                    Password<input type="text" name="password" id="password" value="">*<br>
                    Ciudad <input type="text" name="ciudad" id="ciudad" value="">*<br>
                    Departamento <input type="text" name="departamento" id="departamento" value="">*<br>
                    Urbano Rural 
                    Urbano<input type="radio" name="urb_rur" id="urb_rur" value="">*
                    Rural<input type="radio" name="urb_rur" id="urb_rur" value="">*
                    <br>
                    Notificaciones
                    Correo <input type="checkbox" name="n_email" id="n_email" value="email"> 
                    Whatsapp<input type="checkbox" name="n_whatsapp" id="n_whatsapp" value="whatsapp">
                    Sms<input type="checkbox" name="sms" id="n_sms" value="n_sms"> <br>

                    <input type="text" name="evento" id="evento" value="registro_usuario" style="visibility:hidden"><br>
                    <input type="submit" name="guardar" id="guardar" value="Guardar"><br>
                </form>

            </div>

        </div>
    </div>
    <script type="text/javascript">

        $(document).ready(function () {

            $('#form_registro').submit(function (e) {

                e.preventDefault();
                const data = {
                    nombre: $('#nombre').val(),
                    apellido: $('#apellido').val(),
                    tipo_doc: $('#tipo_doc').val(),
                    documento: $('#documento').val(),
                    email: $('#email').val(),
                    password: $('#password').val(),
                    ciudad: $('#ciudad').val(),
                    departamento: $('#departamento').val(),
                    urb_rur: $('#urb_rur').val(),
                    notificacion: $('#n_email').val() + ',' + $('#n_whatsapp').val() + ',' + $('#n_sms').val(),
                    evento: $('#evento').val(),
                };

                console.log($('#nombre').val());
                if ($('#nombre').val() == '' ||
                        $('#apellido').val() == '' ||
                        $('#tipo_doc').val() == '' ||
                        $('#documento').val() == '' ||
                        $('#email').val() == '' ||
                        $('#password').val() == '' ||
                        $('#ciudad').val() == '' ||
                        $('#departamento').val() == '') {

                    $('div.loader').hide();
                    $('div.mensagem-erro').html('Los campos marcados con * son obligatorios');
                    return false;
                }

                $.ajax({
                    type: 'POST',
                    url: '../Controllers/registroController.php',
                    data: JSON.stringify(data),
                    contentType: 'application/json',
                })
                        .done((data) => {
                            $('div.loader').hide();
                            $('div.mensagem-erro').html(data);
                        })
                        .fail((err) => {
                            console.error(err);
                        })
                        .always(() => {
                            console.log('always called');
                        });
            });
        });
        $(".tab-list").on("click", ".tab", function (event) {
            event.preventDefault();
            $(".tab").removeClass("active");
            $("#form:input").prop("disabled", true);
            $('.input').val('');
            $(".tab-content").removeClass("show");
            $(this).addClass("active");
            $('.input').val('');
            $("#form:input").prop("disabled", false);
            $($(this).attr('href')).addClass("show");
        });

    </script>
</body>

</html>
