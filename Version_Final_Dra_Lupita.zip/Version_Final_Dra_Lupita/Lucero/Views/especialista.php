
<?php
require_once( "../class/login.class.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;

//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>

<html> 
    <head> 

        <link rel="stylesheet" href="./style/style.css">
        <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <title>Especialista</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>
        <script>
            $(function () {
                $("#tabs").tabs();
            });
        </script>
    </head>
    <div style="width: 800px">
      <div style="width:99%;" >
            <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;text-align: right"><a href="index.php"><img style="margin: 0px" src="../image/home.png" width="40px"height="40px"/></a></div>
        </div>
        <br>
        <br>
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">Especialista</a></li>
            </ul>
            <div id="tabs-1" class="tab-content show">
                <div style="width: 100%;float: left;">
                    <div style="width: 55%;float: left;">

                        <textarea name="textarea" rows="10" cols="45" style="resize: none;">Hola soy el, especialista  de cardióloga Pablo rodriguez</textarea>
                    </div>
                    <div style="width: 45%;float: right;text-align: right">
                        <div style="width: 100%;"><img src="../image/PABLO-ASESOR-EN-LINEA--700x590.png" style="width: 30%; height:10 auto;" alt=""></div>
                        <img  src="../image/whatsapp.png" alt="Bootstrap" width="32" height="32"></button>
                        <a href="https://wa.me/0573005370550" target="_blank">¡Chatea con Usuario en WhatsApp!</a>  

                    </div>
                </div>
                <form method="POST" action="../Controllers/archivosController.php" enctype="multipart/form-data">
                    <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                    <p><div class="mensagem-erro"></div></p>
                    <input type="text" id="evento" name="evento" value="carga_archivo_usuario" style="display: none" />
                    <input type="text" id="cedula_return" name="cedula_search" readonly="readonly" style="display: block" />
                    <input type="text" id="nombre_search" name="nombre_search" readonly="readonly" style="display: block" />
                    <input type="text" id="id_usuario" name="id_usuario" readonly="readonly" style="display: block" />
                    <input type="text" id="url_return" name="url_return" readonly="readonly" style="display: none" value="especialista.php" />
                    Cedula paciente<input type="text"  id="cedula" name="cedula" /><button id="busqueda">Buscar Usuario</button>
                    <br>
                    Tipo Examen<select name="tipo_examen" id="tipo_examen">
                        <option value="">--Seleccione Examen--</option>
                        <option value="1">Análisis de orina.</option>
                        <option value="2">Análisis de sangre.</option>
                        <option value="3">Pruebas de laboratorio.</option>
                        <option value="4">Pruebas y exámenes para la tiroides.</option>
                        <option value="5">Pruebas y exámenes para los riñones.</option>
                        <option value="6">Historia Clinica.</option>

                    </select><br>
                    <div>
                        <span>Adjuntar Examenes:</span>
                        <input type="hidden" name="MAX_FILE_SIZE" value="5000000">
                        <br>
                        <br>
                        <b>Enviar un nuevo archivo: </b>
                        <br>
                        <input name="userfile" type="file">
                        <br>
                        <input type="submit" id="cargar" value="Cargar Documento">
                    </div>
                    <div class="container-fluid row">
                        <div class="col-12 align-self-start">
                            <p>Documentos Usuario</p>
                        </div>
                        <div id="detalleseleccion" name="detalleseleccion" style="overflow-x: hidden; overflow-y: auto; height: 16em; border: 1px solid"><p>
                            <table>
                                <tr>
                                    <td>id</td>
                                    <td>Nombre Examen</td>
                                    <td>Archivo</td>  
                                    <td>Fecha</td> 
                                </tr>
                                <tbody id="tabla_tr">
                                </tbody>
                            </table>    
                            </p>
                        </div>
                    </div>


                </form>

            </div>
        </div>
    </div>

</html>

<script type="text/javascript">


    $(document).ready(function () {

        $('#busqueda').click(function (e) {
            $("#tabla_tr").empty('');
            e.preventDefault();
            const data = {
                cedula: $('#cedula').val(),
                evento: 'search_usuario',
            };

            if ($('#cedula').val() == '') {
                $('div.loader').hide();
                $('div.mensagem-erro').html('Los campos marcados con * son obligatorios');
                return false;
            }

            $.ajax({
                type: 'POST',
                url: '../Controllers/usuariosController.php',
                data: JSON.stringify(data),
                contentType: 'application/json',
            }).done((data) => {
                var obj = jQuery.parseJSON(data);
                if (typeof obj.error != "undefined") {
                    console.log(obj.error);
                    $('div.loader').hide();
                    $('div.mensagem-erro').html(obj.error);
                    $('#cedula_return').val('');
                    $('#nombre_search').val('');
                } else {
                    $('#id_usuario').val(obj.id);
                    $('#cedula_return').val(obj.documento);
                    $('#nombre_search').val(obj.nombre);
                    console.log(obj.archivos);
                    td = "";
                    for (i = 0; i < obj.archivos.length; i++) {
                        td += "<tr><td>" + obj.archivos[i]['id_archivo'] + "</td>";
                        td += "<td>" + obj.archivos[i]['tipos_archivos'] + "</td>";
                        td += "<td><a href ='./files/" + obj.archivos[i]['ruta'] + "' target='_blank'>Descargar</td>";
                        td += "<td>" + obj.archivos[i]['fecha_cargue'] + "</td></tr>";
                    }


                    $("#tabla_tr").append(td);
                }


            }).fail((err) => {
                console.error(err);
            }).always(() => {
                console.log('always called');
            });
        });
    });



    $(".tab-list").on("click", ".tab", function (event) {
        event.preventDefault();

        $(".tab").removeClass("active");
        $("#form:input").prop("disabled", true);
        $('.input').val('');
        $(".tab-content").removeClass("show");
        $(this).addClass("active");
        $('.input').val('');
        $("#form:input").prop("disabled", false);
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
