
<?php
require_once( "../class/login.class.php");
require_once( "../class/../Models/epsModels.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;

//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>

<html> 
    <head> 
        <link rel="stylesheet" href="./style/style.css">
        <meta http-equiv="content-type" content="text/html;
              charset = ISO-8859-1">
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <title>Manejo Enfermedades Admin</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>
        <script>
            $(function () {
                $("#tabs").tabs();
            });
        </script>
    </head>
    <div style="width: 800px">
        <div style="width:99%;" >
            <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;text-align: right"><a href="index.php"><img style="margin: 0px" src="../image/home.png" width="40px"height="40px"/></a></div>
        </div>
        <br>
        <br>
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">Manejo Enfermedades Admin</a></li>

            </ul>
            <div id="tabs-1" class="tab-content show">


                <form method="POST" action="../Controllers/archivosController.php" enctype="multipart/form-data">
                    <div class="loader" style="display: none;"><img src="./image/loader.gif" alt="Cargando" /></div>
                    <p><div class="mensagem-erro"></div></p>
                    <input type="text" id="evento" name="evento"  value="carga_slide" style="display: none" />
                    <input type="text" id="url_return" name="url_return" readonly="readonly" style="display: none" value="manejoenferm_admin.php" />
                    <br>
                    <b>Titulo para slide</b>
                    <input type="text" id="titulo" name="titulo"  value="" style="display: block" />
                    <div>
                        <input type="hidden" name="MAX_FILE_SIZE_IMG" value="1000000">
                        <br>
                        <br>
                        <b>Anexar una imagen: </b>
                        <br>
                        <input name="userfile_img" type="file">
                        <br>
                    </div>
                    <div>

                        <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
                        <br>
                        <br>
                        <b>Anexar archivo: </b>
                        <br>
                        <input name="userfile" type="file">
                        <br><br><br>
                        <input type="submit" value="Cargar Slide">
                    </div>
                    <div class="container-fluid row">
                        <div class="col-12 align-self-start">
                            <p>Documentos Usuario</p>
                        </div>
                        <div id="detalleseleccion" name="detalleseleccion" style="overflow-x: hidden; overflow-y: auto; height: 16em; border: 1px solid"><p>                

                            <table>

                                <tr>
                                    <td>id</td>
                                    <td>Nombre Slide</td>
                                    <td>Archivo</td>  
                                    <td>Fecha</td> 
                                </tr>
                                <tbody id="tabla_tr">
                                    <?php
                                    $modelUsuario = new Eps();
                                    $response_archivos = $modelUsuario->slide();
                                    if ($response_archivos != '') {
                                        for ($i = 0; $i < count($response_archivos); $i++) {
                                            echo "<tr>"
                                            . "<td>" . $response_archivos[$i]['id_slide'] . "</td>"
                                            . "<td>" . $response_archivos[$i]['titulo'] . "</td>"
                                            . "<td><a href ='./Files_slide/" . $response_archivos[$i]['ruta'] . "'  target='_blank'>Descargar</td>"
                                            . "<td>" . $response_archivos[$i]['fecha'] . "</td></tr>";
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>

</html>

<script type="text/javascript">


    $(document).ready(function () {


    });


    $(".tab-list").on("click", ".tab", function (event) {
        event.preventDefault();
        $(".tab").removeClass("active");
        $("#form:input").prop("disabled", true);
        $('.input').val('');
        $(".tab-content").removeClass("show");
        $(this).addClass("active");
        $('.input').val('');
        $("#form:input").prop("disabled", false);
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
