
<?php
require_once( "../class/login.class.php");
require_once( "../class/../Models/epsModels.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;
/* Cargo eps existentes */
$eps = Eps::eps();
$tipo_especialidad = Eps::tipo_especialidad();

//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>

<html> 
    <head> 
        <link rel="stylesheet" href="./style/style.css">
        <meta http-equiv="content-type" content="text/html;
              charset = ISO-8859-1">
        <script src="../js/jquery_min.js"></script>
        <script src="../js/jquery_1.11.js"></script>


        <title>jQuery UI Tabs - Default functionality</title>
        <link rel="stylesheet" href="./style/jquery-ui.css">

        <script src="../js/jquery-3.7.1.js"></script>
        <script src="../js/jquery-ui.js"></script>
        <script>
            $(function () {
                $("#tabs").tabs();
            });
        </script>
    </head>
    <div style="width: 800px">
         <div style="width:99%;" >
            <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;text-align: right"><a href="index.php"><img style="margin: 0px" src="../image/home.png" width="40px"height="40px"/></a></div>
        </div>
        <br>
        <br>
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">Promocion y prevencion</a></li>

            </ul>
            <div id="tabs-1" class="tab-content show">

                <div style="width: 100%;float: left;" ></div>

                <table style=" border-style: dashed;border-radius: 10px;">
                    <tbody>
                        <tr>
                            <td style="border:none">
                                <input class="Jquerybutton" type="button" onclick="location.href = 'https://www.minsalud.gov.co/salud/publica/Vacunacion/Paginas/Vacunacion-covid-19.aspx';" value="VACUNACION" />
                            </td>
                            <td style="border:none"> 
                                <input class="Jquerybutton" type="button" onclick="location.href = 'https://www.minsalud.gov.co/sites/rid/lists/BibliotecaDigital/RIDE/INEC/IETS/Gu%C3%ADa.completa.Embarazo.Parto.2013.pdf';"  target="_blank" class="btn btn-light col-3" value="CONTROL PRENATAL"></td>
                            <td style="border:none">
                                <input class="Jquerybutton" type="button" onclick="location.href = 'https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/PP/SNA/Guia-Alimentacion-saludable.pdf'" value="CRECIENDO SANOS: DIETAS"></td>
                        </tr>
                        <tr>
                            <td style="border:none"> <input class="Jquerybutton" type="button" onclick="location.href = 'https://www.minsalud.gov.co/salud/publica/ssr/Paginas/Metodos-anticonceptivos-modernos.aspx';"  target="_blank" class="btn btn-light col-3" value="PLANIFICACION FAMILIA"></td>
                            <td style="border:none"> <input class="Jquerybutton" type="button" onclick="location.href = 'https://www.minsalud.gov.co/salud/publica/HS/Paginas/salud-bucal.aspx';" class="btn btn-light col-3" target="_blank" value="SALUD BUCAL"></td>
                            <td style="border:none"> <input class="Jquerybutton" type="button" onclick="location.href = 'https://www.minsalud.gov.co/Paginas/66-porciento-de-colombianos-declara-haber-enfrentado-algun-problema-de-salud-mental.aspx';" target="_blank" class="btn btn-light col-3" value="SALUD MENTAL"></td>
                        </tr>
                        <tr>
                            <td  colspan="3" style="text-align: center; border:none">  <input class="Jquerybutton" type="button" onclick="location.href = 'https://consultorsalud.com/enfermedades-cronicas-no-transmisibles-colombia/';"  class="btn btn-light col-3" value="ENFERMEDADES CRONICAS"></td>
                        </tr>
                    </tbody>
                </table>
            </div>



        </div>
    </div>
</div>

</html>

<script type="text/javascript">

    $(document).ready(function () {
        /**CARGO FECHA*/

    });
    $(".tab-list").on("click", ".tab", function (event) {
        event.preventDefault();
        $(".tab").removeClass("active");
        $("#form:input").prop("disabled", true);
        $('.input').val('');
        $(".tab-content").removeClass("show");
        $(this).addClass("active");
        $('.input').val('');
        $("#form:input").prop("disabled", false);
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
