
<?php
require_once( "../class/login.class.php");

$objLogin = new Login();

// Verificamos si esta logueado, caso contrario será redireccionado a la página de login
if (!$objLogin->verificar('login.php'))
// Cerramos la verificacion
    exit;

$logueado = array("1" => "Logueado como Usuario", "2" => "Logueado como Doctor", "3" => "Logueado como Administrativo");

$rol = $logueado[$_SESSION['id_rol']];

?>

<html>
    <head> 
        <link rel="stylesheet" href="./style/style.css">
        <title>Doctora Lupita</title>
    </head>

    <div>

        <div>
            <div style="width: 33%;float: left;"><a class="btn btn-danger" href="CerrarSesion.php">Cerrar Sesión</a></div>
            <div style="width: 33%; float: left;"></div>
            <div style="width: 33%; float: right;"><?php echo $rol; ?></div>
        </div>
        <br>
        <br>
        <div>
            <table style=" border-style: dashed;border-radius: 10px;">
                <tbody>
                    <tr>
                        <td colspan="4" style="border:none">
                            <div style="float: left;width: 50%">
                                <a href="manejoenfermedades.php" style="display: <?php echo $objLogin->valida_rol(5) ?>"><img src="../image/enfermedades.png" width="100px"height="100px" alt=""/>Guias manejo enfermedades</a></div>
                            <div style="float: right;width: 50%"> <a href="manejoenferm_admin.php" style="display: <?php echo $objLogin->valida_rol(6) ?>"><img src="../image/enfermedades.png" width="100px"height="100px" alt=""/>Guias manejo enfermedades Admin</a></div></td>
                    </tr>
                    <tr>
                        <td colspan="2" rowspan="5" style="border:none"><img src="../image/lupitalogin.jpg" width="600px"height="600px"/></td>

                        <td colspan="2" style="border:none">
                            <a href="especialista.php" style="display: <?php echo $objLogin->valida_rol(1) ?>"><img src="../image/especialista.png" width="100px"height="100px"/>Especialistas</a>
                            <a href="especialista_usuario.php" style="display: <?php echo $objLogin->valida_rol(2) ?>"><img src="../image/especialista.png" width="100px"height="100px"/>Especialistas Usuario</a>
                        </td>

                    </tr>
                    <tr>
                        <td colspan="2" style="border:none"> <a href="promocionprevencion.php" style="display: <?php echo $objLogin->valida_rol(3) ?>"><img src="../image/prevecionn.png" width="100px"height="100px"/>Promocion y Prevencion</a></td>

                    </tr>
                    <tr>
                        <td style="border:none"> <img src="../image/patrocinador.png" width="100px"height="100px"/>Patrocinador</td>

                        <td style="border:none"><img src="../image/eps.png" width="100px"height="100px"/>Eps</td>

                    </tr>
                    <tr>
                        <td style="border:none"> <a href="eps_usuario.php" style="display: <?php echo $objLogin->valida_rol(4) ?>"><img src="../image/usuario.png" width="100px"height="100px"/>Eps - Usuario</a></td>

                        <td style="border:none"><img src="../image/ips.png" width="100px"height="100px"/>Ips</td>

                    </tr>
                    <tr>
                        <td style="border:none"><img src="../image/historial.png" width="100px"height="100px"/>Historial Clinico</td>
                        <td style="border:none">  <img src="../image/recordatorio.png" width="100px"height="100px"/>Recordatorio</td>

                    </tr>
                </tbody>
            </table>
            <div> 
            </div>
        </div>

    </div>
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
    <script src="../js/jquery_min.js"></script>
    <link href="../js/jquery_css.css" rel="stylesheet" />
    <script src="../js/jquery_1.11.js"></script>

</html>

<script type="text/javascript">

    function myLoop() {         //  create a loop function
        setTimeout(function () {   //  call a 3s setTimeout when the loop is called
            console.log('hello');   //  your code here
            i++;                    //  increment the counter
            if (i < 10) {           //  if the counter < 10, call the loop function
                myLoop();             //  ..  again which will trigger another 
            }                       //  ..  setTimeout()
        }, 300)
    }


    function  parar() {
        clearInterval(refreshIntervalId);
        console.log('paro ejecucion');


    }

    function  reiniciar() {
        refreshIntervalId = setInterval('prueba()', 1500);
        console.log('ejecuto');
        //refreshIntervalId = setInterval('prueba()', 9000);

    }

    function file_get_contents(filename) {
        //   fetch(filename).then((resp) = > resp.text()).then(function(data) {
        return data;
        // });
    }
    function prueba() {
        $("#log").empty();

        llamo_archivo(0);
    }


    a = 1;

    function llamo_archivo(data) {

        console.log("envio_peticion");

        console.log(a);

        url = data;


        console.log(url);

        servicio = $("#servicio option:selected").val();

        console.log(servicio);



        $.ajax({
            data: {'evento': servicio},
            url: 'back2.php',
            dataType: 'txt/json',
            type: 'post',
            success: function (response) {

                $("#log").append(response);
                a++;

                if (response = 'no hay datos para procesar') {
                    clearInterval(refreshIntervalId);
                }

            }

        });
        a++;

    }

    $(document).ready(function () {

    });




    $(".tab-list").on("click", ".tab", function (event) {
        event.preventDefault();

        $(".tab").removeClass("active");
        $("#form:input").prop("disabled", true);
        $('.input').val('');
        $(".tab-content").removeClass("show");
        $(this).addClass("active");
        $('.input').val('');
        $("#form:input").prop("disabled", false);
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
