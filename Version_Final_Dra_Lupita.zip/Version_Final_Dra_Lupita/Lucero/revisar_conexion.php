<?php

include "Models/usuariosModels.php";

$co = new Usuarios();
$conectar = $co->connect();
//var_dump($conectar);
if (!$conectar->connect_error) {
    echo ("Connection ok: " . $conectar->client_info)."<br>";
    die("server_info ok: " . $conectar->server_info);
}

