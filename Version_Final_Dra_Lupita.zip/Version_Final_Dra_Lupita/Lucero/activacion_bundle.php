
<?php
echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));
?>
<html>

    <h1>Tabs</h1>

    <div class="tabs">
        <nav class="tab-list">
            <a class="tab active" href="#tab-1">Activacion Bundle</a>
            <a class="tab" href="#tab-2">Cancelacion Stand Alone</a>
            <a class="tab" href="#tab-3">Tab 3</a>
        </nav>

        <div id="tab-1" class="tab-content show">
            <form method="post" action="procesa_activacion.php">
                cuenta <input type="text" name="cuenta" id="cuenta" value=""><br>
                correo <input type="text" name="correo" id="correo" value=""><br>
                producto <input type="text" name="producto" id="producto" value=""><br>
                bundle_id <input type="text" name="bundle_id" id="bundle_id" value=""><br>
                celular <input type="text" name="celular" id="celular" value=""><br>
                <input type="text" name="evento" id="evento" value="activacion_bundle"><br>
                <input type="submit" name="envia" value="envia">
            </form>

        </div>

        <div id="tab-2" class="tab-content">Lorem ipsum dolor sit amet consectetur adipiscing elit condimentum, litora pellentesque lobortis mus suscipit integer.</div>

        <div id="tab-3" class="tab-content">Sapien hac fermentum erat congue sodales egestas suspendisse lobortis, non tristique quam penatibus vehicula mus ultricies.</div>
    </div>

    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
    <link rel="stylesheet" href="./style/style.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
    <link href="https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css" rel="stylesheet" />
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>

</html>

<script type="text/javascript">

    function myLoop() {         //  create a loop function
        setTimeout(function() {   //  call a 3s setTimeout when the loop is called
            console.log('hello');   //  your code here
            i++;                    //  increment the counter
            if (i < 10) {           //  if the counter < 10, call the loop function
                myLoop();             //  ..  again which will trigger another 
            }                       //  ..  setTimeout()
        }, 300)
    }


    function  parar() {
        clearInterval(refreshIntervalId);
        console.log('paro ejecucion');


    }

    function  reiniciar() {
        refreshIntervalId = setInterval('prueba()', 1500);
        console.log('ejecuto');
        //refreshIntervalId = setInterval('prueba()', 9000);

    }

    function file_get_contents(filename) {
        //   fetch(filename).then((resp) = > resp.text()).then(function(data) {
        return data;
        // });
    }
    function prueba() {
        $("#log").empty();

        llamo_archivo(0);
    }


    a = 1;

    function llamo_archivo(data) {

        console.log("envio_peticion");

        console.log(a);

        url = data;


        console.log(url);

        servicio = $("#servicio option:selected").val();

        console.log(servicio);



        $.ajax({
            data: {'evento': servicio},
            url: 'back2.php',
            dataType: 'txt/json',
            type: 'post',
            success: function(response) {

                $("#log").append(response);
                a++;

                if (response = 'no hay datos para procesar') {
                    clearInterval(refreshIntervalId);
                }

            }

        });
        a++;

    }

    $(document).ready(function() {

    });

    $(".tab-list").on("click", ".tab", function(event) {
        event.preventDefault();

        $(".tab").removeClass("active");
        $(".tab-content").removeClass("show");

        $(this).addClass("active");
        $($(this).attr('href')).addClass("show");
    });

</script>




</html>
