<?php

include '../Models/registroModels.php';

$data = json_decode(file_get_contents('php://input'), true);

//var_dump($data);
//die();
switch ($data['evento']) {
    case "registro_usuario":

        $nombre = $data['nombre'];
        $apellido = $data['apellido'];
        $tipo_doc = $data['tipo_doc'];
        $documento = $data['documento'];
        $email = $data['email'];
        $password = hash("sha512", $data['password']);
        $ciudad = $data['ciudad'];
        $departamento = $data['departamento'];
        $urbano_rural = $data['urb_rur'];
        $notificaciones = $data['notificacion'];
        $modelRegistro = new Registro();
        $existe = $modelRegistro->consulta_usuario($documento);
        if ($existe == null) {
            $result = $modelRegistro->registro_usuario($nombre, $apellido, $tipo_doc, $documento, $email, $password, $ciudad, $departamento, $urbano_rural, $notificaciones);
            $existe_usuario = $modelRegistro->consulta_usuario($documento);
            $result = $modelRegistro->registro_usuario_rol($existe_usuario['id']);
            if ($result == 'true') {
                echo 'Registro exitoso';
            } else {
                echo "error registro";
            }
        } else {
            echo "Usuario Ya existe";
        }


        break;

    case $proceso:


        break;

    default:
        break;
}

    