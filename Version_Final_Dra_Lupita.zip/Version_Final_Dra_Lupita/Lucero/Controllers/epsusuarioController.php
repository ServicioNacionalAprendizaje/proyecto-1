<?php

session_start();
//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));

include '../Models/dispensiarioModels.php';
include '../Models/ipsModels.php';
include '../Models/epsModels.php';

$data = json_decode(file_get_contents('php://input'), true);
$data = isset($data) && $data != null ? $data : $_POST;

switch ($data['evento']) {
    case "consulta_ips_dispensiario":
        $modelsIps = Ips::eps_ips($data['id_eps']);
        $modelsDispensiario = Dispensiario::dispensiario_eps($data['id_eps']);
        $return = array("ips" => $modelsIps, "dispensiario" => $modelsDispensiario);
        if ($return != 'error') {
            echo json_encode($return);
        } else {
            echo json_encode(array("error" => "No se encontaron valores"));
        }
        break;
    case "agendar_citas_examen":
        $id_usuario = $_SESSION['id_usuario'];
        $url_return = $data['url_return'];
        $eps = $data['eps'];
        $ips = $data['ips'];
        $dispensiario = $data['dispensiario'];
        $tipo_cita = $data['tipo_cita'];
        $especialidad = isset($tipo_cita) && $tipo_cita == 'cita' ? $data['cita'] : $data['examen'];

        $fecha_agenda = isset($data['fecha_agenda']) ? $data['fecha_agenda'] : "";

        $modelRegistro = Eps::registro_citas_examen($id_usuario, $eps, $ips, $dispensiario, $especialidad, $fecha_agenda);

        if ($modelRegistro != 'error') {
            $mensaje = "Registro exitoso";
        } else {
            $mensaje = "No se pudo registrar agenda";
        }

        echo "Redireccionando en 2..1<br>";
        header("refresh:2;url=../Views/$url_return");
        echo $mensaje;
        break;

    case "consulta_agenda":
        $modelsIps = Eps::agendas_usuario($_SESSION['id_usuario']);
        if ($modelsIps != 'error') {
            echo json_encode($modelsIps);
        } else {
            echo json_encode(array("error" => "No se encontaron de agenda"));
        }
        break;

    case "archivos_historia":


        break;
    default:
        break;
}
