<?php

include '../Models/usuariosModels.php';

$data = json_decode(file_get_contents('php://input'), true);

//var_dump($data);
//die();
switch ($data['evento']) {
    case "search_usuario":

        $documento = $data['cedula'];

        $modelRegistro = new Usuarios();
        $existe = $modelRegistro->usuario_search($documento);
        if ($existe != 'error') {
            $response_archivos = $modelRegistro->usuario_archivos($existe["id"]);
            $return = array_merge($existe, array("archivos" => $response_archivos));
            echo json_encode($return);
        } else {
            echo json_encode(array("error" => "Usuario no existe"));
        }


        break;

    case $proceso:


        break;

    default:
        break;
}

    