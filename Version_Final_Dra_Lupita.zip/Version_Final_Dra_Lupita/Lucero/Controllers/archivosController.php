<?php

session_start();
//echo $sha = base64_encode(hash('sha256', "1234" . "2022-11-22T17:42:07Z" . "!iTT4tCo"));

include '../Models/usuariosModels.php';
include '../Models/epsModels.php';

switch ($_POST['evento']) {
    case "carga_archivo_usuario":

        $url_return = $_POST['url_return'];
        $ruta = "../Views/Files/";
        $tipo_archivo = $_POST['tipo_examen'];
        $name_file = $_FILES['userfile']['name'];
        $explode = explode(".", $name_file);
        $name_file = date('Ymdhis') . '.' . $explode[1];
        $type_file = $_FILES['userfile']['type'];
        $size_file = $_FILES['userfile']['size'];
        //compruebo si las características del archivo son las que deseo
        if (!((strpos($type_file, "gif") || strpos($type_file, "jpeg") || strpos($type_file, "pdf")) && ($size_file < 50000000))) {
            echo "La extensión o el tamaño de los archivos no es correcta. <br><br><table><tr><td><li>Se permiten archivos .gif o .jpg<br><li>se permiten archivos de 5 MB máximo.</td></tr></table>";
            // header("refresh:2;url=../Views/$url_return");
        } else {
            if (move_uploaded_file($_FILES['userfile']['tmp_name'], $ruta . $name_file)) {
                $id_usuario = isset($_POST['id_usuario']) ? $_POST['id_usuario'] : $_SESSION['id_usuario'];

                $modelRegistro = new Usuarios();
                $existe = $modelRegistro->registro_archivo($id_usuario, $tipo_archivo, $name_file);

                if ($existe != 'errror') {

                    echo "Redireccionando en 2..1<br>";
                    header("refresh:2;url=../Views/$url_return");
                    echo "El archivo ha sido cargado correctamente.";
                    exit();
                } else {
                    echo "Redireccionando en 2..1<br>";
                    header("refresh:2;url=../Views/$url_return");
                    echo "error registro";
                    exit();
                }
            } else {
                echo "Ocurrió algún error al subir el fichero. No pudo guardarse.";
            }
        }



        break;
    case "carga_slide":
        $url_return = $_POST['url_return'];
        $ruta_files = "../Views/Files_slide/";
        $ruta_image = "../Views/image_slide/";
        $name_file = $_FILES['userfile']['name'];
        $explode = explode(".", $name_file);
        $name_file = date('Ymdhis') . '.' . $explode[1];
        $name_file_img = $_FILES['userfile_img']['name'];
        $explode_img = explode(".", $name_file_img);
        $name_file_img = date('Ymdhis') . '.' . $explode_img[1];
        $type_file_archivo = $_FILES['userfile']['type'];
        $type_file_img = $_FILES['userfile_img']['type'];
        $size_file = $_FILES['userfile']['size'];
        $size_file_img = $_FILES['userfile_img']['size'];
        //compruebo si las características del archivo son las que deseo
        if (!((strpos($type_file_archivo, "gif") || strpos($type_file_archivo, "jpeg") || strpos($type_file_archivo, "pdf")) && ($size_file < 10000000))) {
            echo "La extensión o el tamaño de los archivos no es correcta. <br><br><table><tr><td><li>Se permiten archivos .gif o .jpg<br><li>se permiten archivos de 100 Kb máximo.</td></tr></table>";
        } elseif (!((strpos($type_file_img, "gif") || strpos($type_file_img, "jpeg") || strpos($type_file_img, "png")) && ($size_file < 10000000))) {
            echo "La extensión o el tamaño de los archivos no es correcta. <br><br><table><tr><td><li>Se permiten archivos .gif o .jpg<br><li>se permiten archivos de 100 Kb máximo.</td></tr></table>";
        } else {
            if (move_uploaded_file($_FILES['userfile']['tmp_name'], $ruta_files . $name_file) && move_uploaded_file($_FILES['userfile_img']['tmp_name'], $ruta_image . $name_file_img)) {
                $titulo = $_POST['titulo'];
                $epsModels = new Eps();
                $existe = $epsModels->registro_archivo_slide($titulo, $name_file_img, $name_file);
                if ($existe != 'errror') {

                    echo "Redireccionando en 2..1<br>";
                    header("refresh:2;url=../Views/$url_return");
                    echo "El archivo ha sido cargado correctamente.";
                    exit();
                } else {
                    echo "Redireccionando en 2..1<br>";
                    header("refresh:2;url=../Views/$url_return");
                    echo "error registro";
                    exit();
                }
            } else {
                echo "Ocurrió algún error al subir el fichero. No pudo guardarse.";
            }
        }



        break;
    case "especialista_usuario":

        $documento = $_SESSION['documento'];

        $modelRegistro = new Usuario();
        $existe = $modelRegistro->usuario_search($documento);
        if ($existe != 'error') {
            if ($result == 'true') {
                echo 'Registro exitoso';
            } else {
                echo "error registro";
            }
        } else {
            echo "Usuario Ya existe";
        }
        break;
    case "archivos_resultado_ips":


        break;

    case "archivos_rip":


        break;

    case "archivos_historia":


        break;
    default:
        break;
}
