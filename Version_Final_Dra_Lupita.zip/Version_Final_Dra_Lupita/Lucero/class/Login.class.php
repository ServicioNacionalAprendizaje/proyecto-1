<?php

include '../Models/usuariosModels.php';

// Definiendo clase Login
class Login {

    private $tabela, $campoID, $campoNombres, $campoLogin, $campoSenha;

    function __construct($tabela = 'usuario', $campoID = 'id_usuario', $campoNombres = 'nombres', $campoLogin = 'username', $campoSenha = 'contrasena') {

        // Iniciando session
        session_start();

        // Definiendo atributos
        $this->tabela = $tabela;
        $this->campoID = $campoID;
        $this->campoLogin = $campoLogin;
        $this->campoSenha = $campoSenha;
        $this->campoNombres = $campoNombres;
    }

    // ------------------------------------------------------------------------


    function getLogin() {
        return $_SESSION[$this->campoLogin];
    }

    function getNombres() {
        return $_SESSION[$this->campoNombres];
    }

    // ------------------------------------------------------------------------

    function getID() {
        return $_SESSION[$this->campoID];
    }

    // ------------------------------------------------------------------------


    function logar($usuario = null, $clave = null) {

        $modelUsuario = new Usuarios();
        $response = $modelUsuario->usuario_login($usuario, $clave);

        // Se encontrado un usuario
        if ($response != "error") {
            //$response_archivos = $modelUsuario->usuario_archivos($response['id']);
            // Instanciando usuario
            // Registrando sessão
            $_SESSION['id_usuario'] = $response['id'];
            $_SESSION['nombre'] = $response['nombre'];
            $_SESSION['email'] = $response['email'];
            $_SESSION['cedula'] = $response['documento'];
            $_SESSION['id_rol'] = $response['id_rol'];
            //$_SESSION['archivos'] = $response_archivos;
            return true;
        } else
            return false;
    }

    // ------------------------------------------------------------------------


    function verificar($redireciona = null) {
        if (isset($_SESSION['id_usuario']) and isset($_SESSION['nombre']) and isset($_SESSION['email']))
            return true;
        else {
            if ($redireciona !== null)
                header("Location: {$redireciona}");

            return false;
        }
    }

    // ------------------------------------------------------------------------



    function logout($redireciona = null) {
        // Limpa a Sessão
        $_SESSION = array();
        // Destroi a Sessão
        session_destroy();
        // Modifica o ID da Sessão
        session_regenerate_id();
        // Se informado redirecionamento
        if ($redireciona !== null)
            header("Location: {$redireciona}");
    }

    /**
     * Valida roles  y permisos
     * @param type $id_menu
     */
    function valida_rol($id_menu) {

        /* 1 usuario */
        /* 2 Doctor */
        /* 3 Administrativo */
        if ($_SESSION['id_rol'] == 1) {
            $acces = array("1" => "none", "2" => "block", "3" => "block", "4" => "block", "5" => "block", "6" => "none");
        }
        if ($_SESSION['id_rol'] == 2) {
            $acces = array("1" => "block", "2" => "none", "3" => "block", "4" => "none", "5" => "block", "6" => "none");
        }
        if ($_SESSION['id_rol'] == 3) {
            $acces = array("1" => "block", "2" => "none", "3" => "block", "4" => "none", "5" => "block", "6" => "block");
        }
        echo $acces[$id_menu];
    }

}

?>